import tkinter as tk
from tkinter import *
from tkinter import messagebox
import sqlite3

# Conexão e criação da tabela na BD
def inicializar_BD():
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            idade INTEGER NOT NULL,
            genero TEXT
        )
    ''')
    conn.commit()
    conn.close()

# Função principal de validação e inserção
def validar_dados():
    nome = entry_nome.get().strip()
    idade_texto = entry_idade.get().strip()
    genero = genero_var.get()

    # Validação do nome
    if not nome:
        messagebox.showerror("Erro", "O nome não pode estar vazio.")
        return
    if len(nome) > 60:
        messagebox.showerror("Erro", "O nome deve ter no máximo 60 caracteres.")
        return

    # Validação da idade
    try:
        idade = int(idade_texto)
        if not (0 <= idade <= 130):
            messagebox.showerror("Erro", "A idade deve estar entre 0 e 130.")
            return
    except ValueError:
        messagebox.showerror("Erro", "A idade deve ser um número inteiro.")
        return

    # Mensagem personalizada
    if genero == "m":
        tratamento = "Caro"
    elif genero == "f":
        tratamento = "Cara"
    else:
        tratamento = "Caro/a"

    mensagem = f"{tratamento} {nome}, tem {idade} anos"
    messagebox.showinfo("Resultado", mensagem)

    # Salvar na BD
    salvar_na_BD(nome, idade, genero)

    # Limpar campos
    entry_nome.delete(0, tk.END)
    entry_idade.delete(0, tk.END)
    genero_var.set("")

# Inserção na BD
def salvar_na_BD(nome, idade, genero):
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (nome, idade, genero) VALUES (?, ?, ?)", (nome, idade, genero))
    conn.commit()
    conn.close()

# o programa usando Tkinter para guardar os dados validados n1 BD SQLite.
# Interface gráfica
root = tk.Tk()
root.title("Validação de Dados + BD")
root.geometry("400x450")
root.resizable(False, False)

# imagem
canvas = Canvas(height=200, width=200)
logo_img = PhotoImage(file="logo2.png")
canvas.create_image(100,100,image=logo_img)
canvas.pack()

# Nome
tk.Label(root, text="Nome (máx. 60 caracteres):").pack(pady=(10, 0))
entry_nome = tk.Entry(root, width=40)
entry_nome.pack()

# Idade
tk.Label(root, text="Idade (0-130):").pack(pady=(10, 0))
entry_idade = tk.Entry(root, width=10)
entry_idade.pack()

# Género
tk.Label(root, text="Género (opcional):").pack(pady=(10, 0))
genero_var = tk.StringVar(value="não especificar")
frame_genero = tk.Frame(root)
frame_genero.pack()
tk.Radiobutton(frame_genero, text="Masculino", variable=genero_var, value="m").pack(side="left")
tk.Radiobutton(frame_genero, text="Feminino", variable=genero_var, value="f").pack(side="left")
tk.Radiobutton(frame_genero, text="Não especificar", variable=genero_var, value="não especificar").pack(side="left")

# Botão
tk.Button(root, text="Submeter", command=validar_dados).pack(pady=20)

# Inicializar BD e iniciar app
inicializar_BD()
root.mainloop()
