# Content-Security-Policy (CSP)--> eg:permitir folhas de estilo boostrap externo confiáveis
# injeção XSS-->limpar entrados utilizador;sanitazar as entradas do utilizador para não guardar na BD

import os
import bcrypt
from html_sanitizer import Sanitizer
from flask import Flask, render_template, url_for, redirect, flash, send_from_directory
# retirei request
from password_validator import PasswordValidator
from flask_login import UserMixin, login_user, LoginManager, login_required, current_user, logout_user
from dotenv import load_dotenv
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo, Length
from wtforms import ValidationError

# SQLAlchemy puro com ORM moderno
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from sqlalchemy import create_engine, Integer, String, Boolean, select

# carregar variáveis do .env
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')


# ------------ BD
# ORM moderno: SQLAlchemy 2.0+ com DeclarativeBase
class Base(DeclarativeBase):
    pass


# criar engine e sessão (não usar Flask-SQLAlchemy)
engine = create_engine("sqlite:///users.db", echo=False)
Session = sessionmaker(bind=engine)


# modelo moderno com tipagem correta
class User(UserMixin, Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    password: Mapped[str] = mapped_column(String(100), nullable=False)
    name: Mapped[str] = mapped_column(String(50), nullable=False)
    failed_attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    is_locked: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)


# criar BD
Base.metadata.create_all(engine)

# login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'  # Definir view de login


# ----------------Forms
# formulário login
class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Let me in')


# formulário de registo com validação personalizada
class RegistrationForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    name = StringField('Nome', validators=[DataRequired(), Length(min=2, max=50)])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirmar Password',
                                     validators=[DataRequired(),
                                                 EqualTo('password', message='As passwords têm de coincidir.')])
    submit = SubmitField('Sign me up')

    def validate_password(self, field):
        # Usar self para acessar a instância (mesmo que não seja necessário aqui)
        schema = PasswordValidator()
        schema.min(8).max(32).has().uppercase().lowercase().digits().symbols().no().spaces()

        if not schema.validate(field.data):
            raise ValidationError('Password fraca: deve conter entre 8 e 32 caracteres,'
                                  ' com maiúscula, minúscula, número, símbolo e sem espaços.')


# ------------Decoradores
# CSP headers
@app.after_request
def set_csp_headers(response):
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css; "
        "img-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self';"
    )
    return response


# carregar user
@login_manager.user_loader
def load_user(user_id):
    with Session() as session:
        return session.get(User, int(user_id))


# ------------Configurações
# html-sanitizer
sanitizar = Sanitizer({
    'tags': ['neverused'],
    'attributes': {},
    'empty': [],
    'separate': []
})


# ------------Gerir Sessões
# função auxiliar para gerir sessão
def get_db_session():
    return Session()


# ------------Rotas
# rota principal
@app.route('/')
def home():
    return render_template("index.html", logged_in=current_user.is_authenticated)


# registar
@app.route('/register', methods=["GET", "POST"])
def register():
    form = RegistrationForm()

    if form.validate_on_submit():
        with get_db_session() as session:
            email = form.email.data
            existing_user = session.execute(select(User).where(User.email == email)).scalar()

            if existing_user:
                flash('Já existe um utilizador com esse email.', 'warning')
                return redirect(url_for('login'))

            password_bytes = form.password.data.encode('utf-8')
            salt = bcrypt.gensalt()
            hashed_password = bcrypt.hashpw(password_bytes, salt)

            nome_limpo = sanitizar.sanitize(form.name.data) or "Desconhecido"

            new_user = User(
                email=email,
                name=nome_limpo,
                password=hashed_password.decode('utf-8'),
                failed_attempts=0,
                is_locked=False
            )
            session.add(new_user)
            session.commit()

            # Recarregar o usuário para garantir que está na sessão correta
            session.refresh(new_user)
            login_user(new_user)

        return redirect(url_for('secrets'))

    return render_template('register2.html', form=form)


# login
@app.route('/login', methods=["GET", "POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        with get_db_session() as session:
            user = session.execute(select(User).where(User.email == form.email.data)).scalar()

            if not user:
                flash("Email não encontrado.")
                return redirect(url_for('login'))

            if user.is_locked:
                flash("Conta bloqueada após 3 tentativas falhadas.")
                return redirect(url_for('login'))

            if not bcrypt.checkpw(form.password.data.encode('utf-8'), user.password.encode('utf-8')):
                user.failed_attempts += 1
                if user.failed_attempts >= 3:
                    user.is_locked = True
                    flash("Conta bloqueada após 3 tentativas.")
                else:
                    flash(f"Password incorreta. Tentativa {user.failed_attempts}/3.")
                session.commit()
                return redirect(url_for('login'))

            # Reset failed attempts on successful login
            user.failed_attempts = 0
            session.commit()
            session.refresh(user)
            login_user(user)

        return redirect(url_for('secrets'))

    return render_template('login2.html', form=form)


# área protegida
@app.route('/secrets')
@login_required
def secrets():
    return render_template("secrets.html", name=current_user.name, logged_in=True)


# logout
@app.route('/logout')
def logout():
    if current_user.is_authenticated:
        logout_user()
    return redirect(url_for('home'))


# download ficheiro
@app.route('/download')
@login_required
def download():
    return send_from_directory('static', path="files/SegurancaSoftware_flyer.pdf")


# correr aplicação
if __name__ == "__main__":
    app.run(debug=True)
