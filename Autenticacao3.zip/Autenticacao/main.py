# Vulneabilidades corrigidas: atualização da última versão do sw+secret_key em fx .env+
# validar form registo+validar a pwd

from flask import Flask, render_template, request, url_for, redirect, flash, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import Integer, String
from flask_login import UserMixin, login_user, LoginManager, login_required, current_user, logout_user
from dotenv import load_dotenv
import os
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo, Length
import re
from wtforms import ValidationError
# atualizar o requirements.txt   2025-06-15

# Carrega o .env
load_dotenv()

app = Flask(__name__)
# app.config['SECRET_KEY'] = 'secret-key-goes-here'
# substituir por .env
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')
# não imprimiR!!! segredo = os.environ.get('SECRET_KEY') print(segredo)


# CREATE DATABASE
class Base(DeclarativeBase):
    pass


# para verificar se a password >=8 + Maiuscula + minuscula +digito + especial
def password_strength_check(field):
    password = field.data
    if len(password) < 8:
        raise ValidationError('A password deve ter pelo menos 8 caracteres.')
    if not re.search(r'[A-Z]', password):
        raise ValidationError('A password deve conter pelo menos uma letra maiúscula.')
    if not re.search(r'[a-z]', password):
        raise ValidationError('A password deve conter pelo menos uma letra minúscula.')
    if not re.search(r'\d', password):
        raise ValidationError('A password deve conter pelo menos um número.')
    if not re.search(r'[!@#$%^&*()_+\-=\[\]{};\'\\:"|<>,./?]', password):
        raise ValidationError('A password deve conter pelo menos um símbolo.')


# form de registo
class RegistrationForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    name = StringField('Nome', validators=[DataRequired(), Length(min=2, max=50)])
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(min=8),
        password_strength_check  # Validador personalizado aqui
    ])
    confirm_password = PasswordField('Confirmar Password',
                                     validators=[DataRequired(), EqualTo('password',
                                                                         message='As passwords têm de coincidir.')])
    submit = SubmitField('Registar')


app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(model_class=Base)
db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)


# decorador
@login_manager.user_loader
def load_user(user_id):
    return db.get_or_404(User, user_id)


# CREATE TABLE
class User(UserMixin, db.Model):
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(100), unique=True)
    password: Mapped[str] = mapped_column(String(100))
    name: Mapped[str] = mapped_column(String(50))


with app.app_context():
    db.create_all()


# raiz
@app.route('/')
def home():
    return render_template("index.html", logged_in=current_user.is_authenticated)


# registar utilizador
@app.route('/register', methods=["GET", "POST"])
def register():

    form = RegistrationForm()

    if form.validate_on_submit():
        email = form.email.data

        # Verifica se o utilizador já existe
        existing_user = db.session.execute(db.select(User).where(User.email == email)).scalar()
        if existing_user:
            flash('Já existe um utilizador com esse email. Por favor, faça login.',
                  'warning')
            return redirect(url_for('login'))

        # gerar password hash + salt
        hashed_password = generate_password_hash(form.password.data, method='pbkdf2:sha256',
                                                 salt_length=8)
        new_user = User(email=email, name=form.name.data, password=hashed_password)

        db.session.add(new_user)
        db.session.commit()

        login_user(new_user)
        flash('Conta criada com sucesso!', 'success')
        return redirect(url_for('secrets'))

    return render_template('register2.html', form=form)

    # if request.method == "POST":
    #     email = request.form.get('email')
    #     result = db.session.execute(db.select(User).where(User.email == email))
    #
    #     # Note, email in db is unique so will only have one result.
    #     user = result.scalar()
    #     if user:
    #         # User already exists
    #         flash("You've already signed up with that email, log in instead!")
    #         return redirect(url_for('login'))
    #
    #     hash_and_salted_password = generate_password_hash(
    #         request.form.get('password'),
    #         method='pbkdf2:sha256',
    #         salt_length=8
    #     )
    #     new_user = User(
    #         email=request.form.get('email'),
    #         password=hash_and_salted_password,
    #         name=request.form.get('name'),
    #     )
    #     db.session.add(new_user)
    #     db.session.commit()
    #     login_user(new_user)
    #     return redirect(url_for("secrets"))
    #
    # return render_template("register.html", logged_in=current_user.is_authenticated)


# login
@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get('email')
        password = request.form.get('password')

        result = db.session.execute(db.select(User).where(User.email == email))
        user = result.scalar()
        # Email doesn't exist or password incorrect.
        if not user:
            flash("That email does not exist, please try again.")
            return redirect(url_for('login'))
        elif not check_password_hash(user.password, password):
            flash('Password incorrect, please try again.')
            return redirect(url_for('login'))
        else:
            login_user(user)
            return redirect(url_for('secrets'))

    return render_template("login.html", logged_in=current_user.is_authenticated)


# página Bem-vindo
@app.route('/secrets')
@login_required
def secrets():
    return render_template("secrets.html", name=current_user.name, logged_in=True)


# fazer a desconexão do utilizador
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))


# para a descarregar o pdf
@app.route('/download')
@login_required
def download():
    # return send_from_directory('/static/files/', 'SegurancaSoftware_flyer.pdf')
    return send_from_directory('static', path="files/SegurancaSoftware_flyer.pdf")


if __name__ == "__main__":
    # em modo desenvolvimento True, em modo de produção False
    app.run(debug=True)
