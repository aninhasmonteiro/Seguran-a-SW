# Content-Security-Policy (CSP)--> eg:permitir folhas de estilo boostrap externo confiáveis
# injeção XSS-->limpar entrados utilizador;sanitazar as entradas do utilizador para não guardar na BD

# corrigi bool
# usa forms login e register-->wtforms
# usa esquema para validar password -->password_validator
# encripta password-->bcrypt
import os
import re
import bcrypt
# import bleach   depreciated/obsoleto --> bleach==6.2.0
from html_sanitizer import Sanitizer
# import logging
from flask import Flask, render_template, request, url_for, redirect, flash, send_from_directory
# from werkzeug.security import generate_password_hash, check_password_hash
from password_validator import PasswordValidator
from flask_sqlalchemy import SQLAlchemy
# from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy import Integer, String, Boolean
from flask_login import UserMixin, login_user, LoginManager, login_required, current_user, logout_user
from dotenv import load_dotenv
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo, Length
from wtforms import ValidationError
# atualizar o requirements.txt   2025-06-21

# Carrega o .env
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')
# não imprimiR!!! segredo = os.environ.get('SECRET_KEY') print(segredo)


# CREATE DATABASE
# class Base(DeclarativeBase):
#     pass


app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy()
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)


# CREATE TABLE
class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100))
    name = db.Column(db.String(50))
    failed_attempts = db.Column(db.Integer, default=0)
    is_locked = db.Column(db.Boolean, default=False)


with app.app_context():
    db.create_all()


# ------------------------------------------Forms
# Form login
class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Let me in')


# Form register
class RegistrationForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    name = StringField('Nome', validators=[DataRequired(), Length(min=2, max=50)])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirmar Password',
                                     validators=[DataRequired(),
                                                 EqualTo('password',
                                                         message='As passwords têm de coincidir.')])
    submit = SubmitField('Sign me up')


# ---------------------configurações
# sistema de log ==== a explorar +tarde
# logging.basicConfig(
#     filename='app.log',
#     level=logging.INFO,
#     format='%(asctime)s - %(levelname)s - %(message)s'
# )

# Criar o configurador corretamente com um dicionário
config = {
    'tags': ['neverused'],  # Tag falsa para evitar permitir tags reais
    'attributes': {},
    'empty': [],
    'separate': []  # Evita o conflito com tags de bloco
}
sanitizar = Sanitizer(config)


# ----------------Decoradores
# user existente
@login_manager.user_loader
def load_user(user_id):
    return db.get_or_404(User, user_id)


# definir as ligações externas -->Content-Security-Policy (CSP)
@app.after_request
def set_csp_headers(response):
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css; "
        "img-src 'self'; "
        "object-src 'none'; "
        "base-uri 'self'; "
        "form-action 'self'; "
    )
    return response


# para verificar se a password >=8 + Maiuscula + minuscula +digito + especial
def password_strength_check(form, field):
    password = field.data
    if len(password) < 8:
        raise ValidationError('A password deve ter pelo menos 8 caracteres.')
    if not re.search(r'[A-Z]', password):
        raise ValidationError('A password deve conter pelo menos uma letra maiúscula.')
    if not re.search(r'[a-z]', password):
        raise ValidationError('A password deve conter pelo menos uma letra minúscula.')
    if not re.search(r'\d', password):
        raise ValidationError('A password deve conter pelo menos um número.')
    if not re.search(r'[!@#$%^&*()_+\-=\[\]{};\'\\:"|<>,./?]', password):
        raise ValidationError('A password deve conter pelo menos um símbolo.')


# Criação de um esquema para a validação da password
schema = PasswordValidator()
schema.min(8)
schema.max(32)
schema.has().uppercase()
schema.has().lowercase()
schema.has().digits()
schema.has().symbols()
schema.has().no().spaces()


# Validador personalizado para ver força da password
def validate_password(self, field):
    if not schema.validate(field.data):
        # Pode-se detalhar os erros, por exemplo:
        # details = schema.validate(field.data, details=True)
        # Gerar mensagem de erro simples
        raise ValidationError('Password fraca: deve conter entre 8 e 32 caracteres,'
                              ' pelo menos uma maiúscula, uma minúscula, '
                              'um número, um símbolo e não conter espaços.')


# ----------------------------------------- routes
# raiz
@app.route('/')
def home():
    return render_template("index.html", logged_in=current_user.is_authenticated)


# registar utilizador
@app.route('/register', methods=["GET", "POST"])
def register():
    form = RegistrationForm()

    if form.validate_on_submit():
        email = form.email.data

        # Verifica se o utilizador já existe
        existing_user = db.session.execute(db.select(User).where(User.email == email)).scalar()
        if existing_user:
            flash('Já existe um utilizador com esse email. Por favor, faça login.', 'warning')
            return redirect(url_for('login'))

        # gerar hash com bcrypt
        password_bytes = form.password.data.encode('utf-8')
        salt = bcrypt.gensalt()
        hashed_password = bcrypt.hashpw(password_bytes, salt)
        # bcrypt.hashpw retorna bytes, por isso devemos armazenar como string

        # Sanitizar o input do utilizador com html-sanatizer (para prevenir XSS persistente)
        # testar nome com: <script>alert(1)</script> ou <script>alert("Olá Mundo");</script>
        nome_limpo = sanitizar.sanitize(form.name.data)
        if nome_limpo == "":
            nome_limpo = "Desconhecido"
        new_user = User(
            email=email,
            name=nome_limpo,
            password=hashed_password.decode('utf-8')
        )
        db.session.add(new_user)
        db.session.commit()

        login_user(new_user)
        # flash('Conta criada com sucesso!', 'success')
        return redirect(url_for('secrets'))

    return render_template('register2.html', form=form)


# login
@app.route('/login', methods=["GET", "POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()

        if not user:
            flash("Email não encontrado.")
            return redirect(url_for('login'))

        if user.is_locked:
            flash("Conta bloqueada após 3 tentativas falhadas. Contacte o administrador.")
            return redirect(url_for('login'))

        if not bcrypt.checkpw(form.password.data.encode('utf-8'),
                              user.password.encode('utf-8')):
            user.failed_attempts += 1
            if user.failed_attempts >= 3:
                user.is_locked = True
                flash("Conta bloqueada após 3 tentativas.")
            else:
                flash(f"Password incorreta. Tentativa {user.failed_attempts}/3.")
            db.session.commit()
            return redirect(url_for('login'))

        # login bem-sucedido
        user.failed_attempts = 0
        db.session.commit()
        login_user(user)
        # flash("Login efetuado com sucesso!", 'success')
        return redirect(url_for('secrets'))

    return render_template('login2.html', form=form)


# página Bem-vindo
@app.route('/secrets')
@login_required
def secrets():
    return render_template("secrets.html", name=current_user.name, logged_in=True)


# fazer a desconexão do utilizador
@app.route('/logout')
# @login_required
def logout():
    if current_user.is_authenticated:
        logout_user()
    return redirect(url_for('home'))


# para a descarregar o pdf
@app.route('/download')
@login_required
def download():
    # return send_from_directory('/static/files/', 'SegurancaSoftware_flyer.pdf')
    return send_from_directory('static', path="files/SegurancaSoftware_flyer.pdf")


# --- programa principal
if __name__ == "__main__":
    # em modo desenvolvimento True, em modo de produção False
    app.run(debug=True)
